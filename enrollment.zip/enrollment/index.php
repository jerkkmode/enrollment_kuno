
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="icon" href="./img/excel.ico" type="image" sizes="16x16">
	<title>Excel Technical Skills and Career Center</title>
	<style type="text/css">
		a{
		color: white;
		padding:0px 30px 0px;
		}
		#idLogo{
		height: 50px;
		width: 50px;
		margin-left: 150px;
	}
	#idTitle{
		font-family: Cambria;
		font-size: 150%;
		margin: 0px 0px;
		padding: 0px 0px;
	}
	.app-footer {
		background-color: #333333;
		color: white;
		padding: 50px;
		font-size: 15px;
	}
	</style>
</head>
<body style="padding-top: 130px">
	<header class= "bg-success text-white p-15 mb-5 navbar navbar-expand-lg fixed-top">
		<div class="container">
		<img id="idLogo" src="./img/logo.jpg"><p id="idTitle">Excel Technical Skills and Training Center </p>
		</div>
		<div class="nav navbar">
			<ul style="list-style: none; display: inline-flex; padding-left: 250px; ">
				<a class="navbar-brand" href="index.php">Home</a>
				<a class="navbar-brand" href="about.php">About Us</a>
				<a class="navbar-brand" href="courses.php">Courses</a>
			</ul>
		</div>
	</header>
	<div class="container">	
		<div class="jumbotron text-center">
			<h2>Welcome to Excel Technical Skills and Training Center!</h2>
		</div>
	</div>		
	<div class="container">
		<a href="register.php" style="color: black;">
			<div class="jumbotron text-center" style="background-color: #1aeb28">
				<h2 class="navbar-brand" style="font-size: 90px; color: white">Register Now!</h2>
			</div>
		</a>
	</div>
	<div class="container">
		<h3>Our Offered Courses</h3>
		<div class="row">
			<img src="./img/wbdes.png">
			<img src="./img/wbdv.jpg">
			<img src="./img/ems.jpg">
			<img src="./img/tm.jpg">		
		</div>		
	</div>



	<footer class="app-footer">
	    <div>
	        <span>Created by &copy;<a href="https://getbootstrap.com">jerkkmode</a></span>
	      </div>
  	</footer>

</body>	
</html>