<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="icon" href="./img/excel.ico" type="image" sizes="16x16">
	<title>Excel Technical Skills and Career Center</title>
	<style type="text/css">
	a{
			color: white;
			padding:0px 30px 0px;
		}
	#idLogo{
		height: 50px;
		width: 50px;
		margin-left: 150px;
	}
	#idTitle{
		font-family: Cambria;
		font-size: 150%;
		margin: 0px 0px;
		padding: 0px 0px;
	}	
	.form-group {
		display: inline-grid;
	}
	.form{
		
	}

	</style>
</head>
<body style="margin-bottom: 900px">
	<header class= "bg-success text-white p-15 mb-5 navbar navbar-expand-lg">
		<div class="container">
		<img id="idLogo" src="./img/logo.jpg"><p id="idTitle">Excel Technical Skills and Training Center </p>
		</div>
		<div class="nav navbar">
			<ul style="list-style: none; display: inline-flex;  padding-left: 250px; ">
				<a class="navbar-brand" href="index.php">Home</a>
				<a class="navbar-brand" href="about.php">About Us</a>
				<a class="navbar-brand" href="courses.php">Courses</a>
			</ul>
		</div>
	</header>
	<div class="container">
		<div class="jumbotron">
			<h4 style="font-family: 'Cambria';">Please fill out the application form for new students</h4>
		</div>
		<div class="container">
			<form method="POST" action="config.php">
			<div class="form-group">
				<label>First Name</label>
				<input type="text" name= "fname" class="form-control" placeholder=" ex. Mark" required="">
			</div>
			<div class="form-group">
				<label>Middle Name</label>
				<input type="text" name= "mname" class="form-control" placeholder=" ex. Johnson" required="" >
			</div>
			<div class="form-group">
				<label>Last Name</label>
				<input type="text" name= "lname" class="form-control" placeholder=" ex. Dela Cruz" required="" >
			</div>
			<div class="form-group">
				<label>Age</label>
				<input type="num" name= "age" class="form-control" placeholder=" ex. 64" required="" >
			</div>
			<div class="form-group">
				<label>Birthdate</label>
				<input type="date" name= "bday" max="2001-12-31" class="form-control" required="" >
			</div>
			<div class="form-group">
				<label>Sex</label>
				<select name="sex" required="">
	   				<option selected="" >Female</option>
	    			<option>Male</option>
  				</select>
			</div>
			<div class="form-group">
				<label>Block/Lot/Street</label>
				<input type="text" name= "strtname" class="form-control" placeholder=" ex. 1 blk 1 lot"  >
			</div>
			<div class="form-group">
				<label>Brgy/Village</label>
				<input type="text" name= "brgy" class="form-control" placeholder=" ex. San Roque" >
			</div>
			<div class="form-group">
				<label>City/Municipality</label>
				<input type="text" name= "city" class="form-control" placeholder=" ex. Marinduque" >
			</div>
			<div class="form-group">
				<label>Telephone No.</label>
				<input type="tel" name= "telephone" class="form-control" placeholder=" ex.000-00-00" pattern="[0-9]{3}-[0-9]{2}-[0-9]{2}" >
			</div>
			<div class="form-group">
				<label>Contact No.</label>
				<input type="tel" name= "contact" class="form-control" placeholder=" ex. 09123456789" pattern="[0-9]{11}" >
			</div>
			<div class="form">
				<label>Did you take a TESDA Accredited training before?</label>
				<input type="radio" name="chooseone" value="yes" checked>Yes
				<input type="radio" name="chooseone" value="no">No
			</div>
			<div class="form">
				<label>If Yes, Please indicate the duration, training center, and the assesor:</label>
				<textarea rows="6" cols="60"></textarea>
			</div>
			<div class="form-group">
				<label>If not, what course are you taking?</label>
				<select name="course" >
	   				<option>Creative Web Design</option>
	    			<option>Web Development</option>
	    			<option>Trainer's Methodology</option>
	    			<option>Event's Management</option>
  				</select>
			</div>
			<br>			
			<button type="submit" name="submit" class="btn btn-success" style="color: white;">Submit</button>
			</form>
		</div>
	</div>
</body>
</html>